Assets readme
