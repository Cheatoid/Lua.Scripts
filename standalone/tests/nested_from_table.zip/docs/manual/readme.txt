Manual readme
